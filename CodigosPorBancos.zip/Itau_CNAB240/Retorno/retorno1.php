<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>

<link href="css/index.css" rel="stylesheet" type="text/css">
<link href="css/geral.css" rel="stylesheet" type="text/css">
<link href="css/geral2.css" rel="stylesheet" type="text/css">

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>RETORNO ITAU CNAB 240</title>

</head>

<body>
<table width="990" border="0">
  <tr>
    <td>PROCESSAR ARQUIVO DE RETORNO DO BANCO ITA&Uacute; - CNAB-240 </td>
  </tr>
  <tr>
    <td><form action="retorno2.php" method="post" enctype="multipart/form-data" name="enviar" id="enviar">
      <table width="100%" border="0" cellspacing="2" cellpadding="2">
        <tr>
          <td width="32%"><div align="right"><span class="label_normal">Arquivo de Retorno:</span> </div></td>
          <td width="67%"><div align="left">
              <input type="file" name="arquivo" id="arquivo" />
          </div></td>
        </tr>
        <tr>
          <td>&nbsp;</td>
          <td><div align="left">
              <input name="Proximo" type="submit" class="label_titulo" value="Avan&ccedil;ar" />
          </div></td>
        </tr>
      </table>
    </form></td>
  </tr>
</table>
</body>

</html>
